# 1
car = {"марка": "Nissan", "модель": "Qashqai", "год": 2022}
car["цвет"] = "черный"
print(f"{car['марка'] = }")

# 2
fruits = []
fruits.append("Банан")
fruits.append("Яблоко")
fruits.append("Груша")
print(f"{fruits[0] = }")

# 3
numbers = (1, 3, 5, 2, 4, 6)
print(f"{numbers[-1] = }")
